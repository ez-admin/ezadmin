package com.ez.util;

/**
 * Created by john on 2016/6/24 0024.
 */
public class ValidateResult {
    private String message;
    private Boolean valid;
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public Boolean getValid() {
        return valid;
    }
    public void setValid(Boolean valid) {
        this.valid = valid;
    }
}
