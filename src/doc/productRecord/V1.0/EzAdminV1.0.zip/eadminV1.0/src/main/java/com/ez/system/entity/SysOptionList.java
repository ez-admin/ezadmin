package com.ez.system.entity;

import java.util.List;

/**
 * Created by Administrator on 2017/5/6.
 */
public class SysOptionList {

    private List<SysOption> sysOptionList;
    public List<SysOption> getSysOptionList() {
        return sysOptionList;
    }
    public void setSysOptionList(List<SysOption> sysOptionList) {
        this.sysOptionList = sysOptionList;
    }

   /* public SysOptionList(){super();}
    public SysOptionList(List<SysOption> sysOptionList){
        super();
        this.sysOptionList=sysOptionList;
    }*/


}
