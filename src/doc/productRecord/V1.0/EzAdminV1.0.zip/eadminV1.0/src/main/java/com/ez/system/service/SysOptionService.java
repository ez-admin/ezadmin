/*
 * Powered By [chenen_genetrator]
 * version 1.0
 * Since 2016 - 2017
 */

package com.ez.system.service;

import com.ez.base.service.BaseService;
import com.ez.system.entity.SysOption;


/**
 * @author chenez
 * @2017-04-18
 * @Email: chenez 787818013@qq.com
 * @version 1.0
 */
public interface SysOptionService extends BaseService<SysOption> {

    /*void test();*/
}
