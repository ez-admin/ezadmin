package com.ez.login.service;

import com.ez.system.entity.SysUser;

public interface LoginService {
	int checkUser(SysUser sysUser);
}
