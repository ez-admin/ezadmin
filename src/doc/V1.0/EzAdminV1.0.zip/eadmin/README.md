# ezadmin

ezadmin 集成了SSM框架+maven 系统后台页面集成layui框架

- 1、页面表格集成boostrap table
- 2、后台集成shiro安全框架
- 3、缓存echache缓存处理
