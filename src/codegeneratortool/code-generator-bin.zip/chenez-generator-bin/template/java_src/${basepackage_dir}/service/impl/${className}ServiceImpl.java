<#include "/java_copyright.include">
<#assign className = table.className>   
<#assign classNameLower = className?uncap_first> 
package ${basepackage}.service.impl;

import com.ez.annotation.SystemLogService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

<#include "/java_imports.include">
<#include "/java_author.include">
@Transactional
@Service("${classNameLower}Service")
public class ${className}ServiceImpl implements ${className}Service {
	@Autowired
	private ${className}Dao ${classNameLower}Dao;


}
