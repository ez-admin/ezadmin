<#include "/java_copyright.include">
<#assign className = table.className>   
<#assign classNameLower = className?uncap_first> 
package ${basepackage}.service;
import com.github.pagehelper.Page;
import java.util.List;
<#include "/java_imports.include">

<#include "/java_author.include">
public interface ${className}Service extends BaseService<${className}> {
}
