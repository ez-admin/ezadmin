<#include "/custom.include">
<#include "/java_copyright.include">
<#assign className = table.className>   
<#assign classNameFirstLower = className?uncap_first>   
<#assign classNameLowerCase = className?lower_case>   
<#assign pkJavaType = table.idColumn.javaType>   

package ${basepackage}.controller;

import com.ez.annotation.SystemLogController;
import com.ez.util.Jurisdiction;
import com.ez.util.PubConstants;
import com.ez.util.WebTool;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

<#include "/java_imports.include">
<#include "/java_author.include">
@Controller
@RequestMapping(value="/${namespace}/${classNameLowerCase}/")
public class ${className}Controller {

	String menuUrl = "/${namespace}/${classNameLowerCase}/list.do"; //菜单地址(权限用)
	@Resource
	private ${className}Service ${classNameFirstLower}Service;


	/** binder用于bean属性的设置 */
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		binder.registerCustomEditor(Date.class, new CustomDateEditor(new SimpleDateFormat("yyyy-MM-dd"), true));
	}

	/**
	 * 跳到列表页面
	 * @param model
	 * @return
	 */
	@RequestMapping(value="list")
	@SystemLogController(description = "跳到${table.tableAlias}列表页面")
	public String list(Model model){
		model.addAttribute(PubConstants.SESSION_QX,WebTool.getSessionQx());
		return "/${namespace}/${classNameLowerCase}/list";
	}

	/**
	 * 跳到新增页面
	 * @return
	 */
	@RequestMapping(value="addUI")
	@SystemLogController(description = "跳到${table.tableAlias}新增页面")
	public String addUI(){
		return "/${namespace}/${classNameLowerCase}/add";
	}
	
	/**
	 * 保存新增
	 * @param response
	 * @param ${classNameLowerCase}
	 * @return
	 */
	@RequestMapping(value="add")
	@SystemLogController(description = "保存${table.tableAlias}新增信息")
	public String add(${className} ${classNameLowerCase},HttpServletResponse response){
		String result="{\"msg\":\"suc\"}";
		try {
			if(Jurisdiction.buttonJurisdiction(menuUrl, "add")){
				${classNameFirstLower}Service.add(${classNameLowerCase});
			}else{
				result="{\"msg\":\"fail\",\"message\":\"您无增加权限！\"}";
			}
		} catch (Exception e) {
			result="{\"msg\":\"fail\",\"message\":\"" +WebTool.getErrorMsg(e.getMessage())+"\"}";
			e.printStackTrace();
		}
		 WebTool.writeJson(result, response);
		 return null;
	}
	
	/**
	 * post方式分页查询
	 * @param page
	 * @param ${classNameLowerCase}
	 * @return map
	 */
	@RequestMapping(value="showlist",method=RequestMethod.POST)
    @ResponseBody
	@SystemLogController(description = "跳到分页查询${table.tableAlias}信息")
	public Map<String, Object> showlist(Page<${className}> page,${className} ${classNameLowerCase}){
		List<${className}> list = ${classNameFirstLower}Service.query(page, ${classNameLowerCase});
		PageInfo<${className}> pageInfo = new PageInfo<${className}>(list);
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("rows", list);
		map.put("total", pageInfo.getTotal());
		return map;
	}
	
	/**
	 * 根据id删除
	 * @param model
	 * @param ids
	 * @return
	 */
	@RequestMapping(value="deleteById",method=RequestMethod.POST)
	@SystemLogController(description = "删除${table.tableAlias}信息")
	public String deleteById(Model model,String ids, HttpServletResponse response){
		String result="{\"status\":1,\"message\":\"删除成功！\"}";
		try{
			if(Jurisdiction.buttonJurisdiction(menuUrl, "del")) {
				${classNameFirstLower}Service.delete(ids);
			}else {
				result="{\"status\":0,\"message\":\"您无删除权限！\"}";
			}
		}catch(Exception e){
			result="{\"status\":0,\"message\":\"" +WebTool.getErrorMsg(e.getMessage())+"\"}";
			e.printStackTrace();
		}
		WebTool.writeJson(result, response);
		return null;
	}
	
	/**
	 * 查询&修改单条记录
	 * @param model
	 * @param ${classNameLowerCase}Id
	 * @param typeKey
	 * @return
	 */
	@RequestMapping(value="getById")
	@SystemLogController(description = "跳到查询&修改${table.tableAlias}单条记录页面")
	public String getById(Model model,String ${classNameLowerCase}Id,int typeKey){
		${className} ${classNameLowerCase} = ${classNameFirstLower}Service.getById(${classNameLowerCase}Id);
		model.addAttribute("${classNameLowerCase}", ${classNameLowerCase});
		if(typeKey == 1){
			return "/${namespace}/${classNameLowerCase}/edit";
		}else if(typeKey == 2){
			return "/${namespace}/${classNameLowerCase}/view";
		}else{
			return "/${namespace}/${classNameLowerCase}/view_1";
		}
	}
	
	/**
	 * 更新修改的信息
	 * @param model
	 * @param ${classNameLowerCase}
	 * @return
	 */
	@RequestMapping(value="update",method=RequestMethod.POST)
	@SystemLogController(description = "更新修改${table.tableAlias}的信息")
	public String update${className}(Model model,${className} ${classNameLowerCase},HttpServletResponse response){
		String result="{\"msg\":\"suc\"}";
		try {
			if(Jurisdiction.buttonJurisdiction(menuUrl, "edit")) {
				${classNameFirstLower}Service.modify(${classNameLowerCase});
			}else {
				result="{\"msg\":\"fail\",\"message\":\"您无修改权限！\"}";
			}
		} catch (Exception e) {
			result="{\"msg\":\"fail\",\"message\":\"" +WebTool.getErrorMsg(e.getMessage())+"\"}";
			e.printStackTrace();
		}
		 WebTool.writeJson(result, response);
		 return null;		
	}

	/**
	 * 批量删除数据
	 * @param response
	 * @param ids
	 * @return
	 */
	@RequestMapping(value = "deleteAll")
	@SystemLogController(description = "批量删除${table.tableAlias}信息")
	public String deleteAll(String[] ids, HttpServletResponse response) {
		String result = "{\"status\":1,\"message\":\"删除成功！\"}";
		try {
			if(Jurisdiction.buttonJurisdiction(menuUrl, "del")) {
				for (String id : ids) {
					${classNameFirstLower}Service.delete(id);
				}
			}else {
				result="{\"status\":0,\"message\":\"您无删除权限！\"}";
			}
		} catch (Exception e) {
			result="{\"status\":0,\"message\":\"" +WebTool.getErrorMsg(e.getMessage())+"\"}";
			e.printStackTrace();
		}
		WebTool.writeJson(result, response);
		return null;
	}
	
}

