<#include "/macro.include"/>
<#include "/java_copyright.include">
<#assign className = table.className>   
<#assign classNameLower = className?uncap_first> 
package ${basepackage}.vo;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import com.xhs.poi.util.ExcelResources;
import ${basepackage}.entity.*;
import java.util.List;
import java.util.ArrayList;
import java.io.Serializable;

<#include "/java_author.include">

public class ${className}VO implements Serializable {
    private static final long serialVersionUID = 3148176768559230877L;
    
	<@generateFields/>
	<@generateProperties/>

	public static List<${className}> getBO(List<Object> objs) {
		List<${className}> list = new ArrayList<${className}>();
		for(Object obj:objs) {
			${className}VO vo = (${className}VO)obj;
			list.add(vo.getField());
		}
		return list;
	}

	public ${className} getField() {
		${className} bo = new ${className}();
		<#list table.notPkColumns as column>
		bo.set${column.columnName}(this.${column.columnNameLower});
		</#list>
		return bo;
	}
	
	public String toString() {
		return ToStringBuilder.reflectionToString(this,ToStringStyle.MULTI_LINE_STYLE);
	}
	
}

<#macro generateFields>

	<#list table.columns as column>
	/** ${column.columnAlias} */
	<#if column.isDateTimeColumn && !column.contains("begin,start,end")>
	private ${column.javaType} ${column.columnNameLower}Begin;
	private ${column.javaType} ${column.columnNameLower}End;
	</#if>
	private ${column.javaType} ${column.columnNameLower};
	
	</#list>

</#macro>

<#macro generateProperties>
	<#list table.columns as column>
	<#if column.isDateTimeColumn && !column.contains("begin,start,end")>
	public ${column.javaType} get${column.columnName}Begin() {
		return this.${column.columnNameLower}Begin;
	}
	
	public void set${column.columnName}Begin(${column.javaType} value) {
		this.${column.columnNameLower}Begin = value;
	}	
	
	public ${column.javaType} get${column.columnName}End() {
		return this.${column.columnNameLower}End;
	}
	
	public void set${column.columnName}End(${column.javaType} value) {
		this.${column.columnNameLower}End = value;
	}
	
	</#if>
	
	<#if column.pk>
	<#else>
	@ExcelResources(title="${column.columnAlias}",order=${column_index})
	</#if>
	public ${column.javaType} get${column.columnName}() {
		return this.${column.columnNameLower};
	}
	
	public void set${column.columnName}(${column.javaType} value) {
		this.${column.columnNameLower} = value;
	}
	
	</#list>
</#macro>




