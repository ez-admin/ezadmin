<#include "/java_copyright.include">
<#assign className = table.className>   
<#assign classNameLower = className?uncap_first> 
package ${basepackage}.service.impl;

import com.ez.annotation.SystemLogService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

<#include "/java_imports.include">
<#include "/java_author.include">
@Transactional
@Service("${classNameLower}Service")
public class ${className}ServiceImpl implements ${className}Service {
	@Resource
	private ${className}Dao ${classNameLower}Dao;
	
	/**
	 * 分页查询
	 * @param page
	 * @param ${classNameLower}
	 * @return List<${className}>
	 */
	//@PreAuthorize("hasRole('ROLE_*')")
	@Transactional(readOnly=true)
	@SystemLogService(description = "分页查询${table.tableAlias}异常")
	public List<${className}> query(Page<${className}> page, ${className} ${classNameLower}) {
		PageHelper.startPage(page.getPageNum(),page.getPageSize(),page.getOrderBy());
		List<${className}> list = ${classNameLower}Dao.query(${classNameLower});
		return list;
	}
	
	/**
	 * 不分页查询
	 * @param ${classNameLower}
	 * @return List<${className}>
	 */
	//@PreAuthorize("hasRole('ROLE_*')")
	@Transactional(readOnly=true)
	@SystemLogService(description = "不分页查询${table.tableAlias}异常")
	public List<${className}> queryAll(${className} ${classNameLower}) {
		List<${className}> list = ${classNameLower}Dao.query(${classNameLower});
		return list;
	}
	
	/**
	 * 新增操作
	 * @param ${classNameLower}
	 * @return
	 */
	//@PreAuthorize("hasRole('ROLE_*')")
	@SystemLogService(description = "保存${table.tableAlias}异常")
	public void add(${className} ${classNameLower}) {
		${classNameLower}Dao.add(${classNameLower});
	}
	
	/**
	 * 新增操作
	 * @param ${classNameLower}
	 * @return
	 */
	//@PreAuthorize("hasRole('ROLE_*')")
	@SystemLogService(description = "保存${table.tableAlias}异常")
	public void addAll(${className} ${classNameLower}) {
		${classNameLower}Dao.addAll(${classNameLower});
	}
	
	/**
	 * 删除操作
	 * @param id
	 * @return
	 */
	//@PreAuthorize("hasRole('ROLE_*')")
	@SystemLogService(description = "删除${table.tableAlias}异常")
	public void delete(String id) {
		${classNameLower}Dao.delete(id);
	}
	
	/**
	 * 根据id查找实体类
	 * @param id
	 * @return
	 */
	//@PreAuthorize("hasRole('ROLE_*')")
	@Transactional(readOnly=true)
	@SystemLogService(description = "根据id查找${table.tableAlias}异常")
	public ${className} getById(String id) {
		return ${classNameLower}Dao.getById(id);
	}
	
	/**
	 * 修改实体类
	 * @param ${classNameLower}
	 * @return
	 */
	//@PreAuthorize("hasRole('ROLE_*
	@SystemLogService(description = "修改${table.tableAlias}异常")
	public void modify(${className} ${classNameLower}) {
		${classNameLower}Dao.modify(${classNameLower});
	}

	/**
	 * 查找所有
	 * @return
	 */
	//@PreAuthorize("hasRole('ROLE_*')")
	@Transactional(readOnly=true)
	@SystemLogService(description = "查找所有${table.tableAlias}异常")
	public List<${className}> findAll() {
		return ${classNameLower}Dao.findAll();
	}

}
