<#include "/custom.include"/>  
<#assign className = table.className>   
<#assign classNameLower = className?uncap_first>
<#assign classNameLowerCase = className?lower_case>
<#assign id = 97>
<#assign orders = 3>
<#assign id1 = 106>

INSERT INTO `resources`  VALUES (${id}, '${table.tableAlias}管理', '1010', 'sys_${classNameLowerCase}', '0', '${classNameLowerCase}', '${orders}', '${table.tableAlias}管理');
INSERT INTO `resources`  VALUES (${id1}, '${table.tableAlias}列表', '${id}', 'sys_list_${classNameLowerCase}', '1', '${actionBasePath}/query.html', '1', '${table.tableAlias}列表');
INSERT INTO `resources` (`name`, `parentId`, `resKey`, `type`, `resUrl`, `level`, `description`) VALUES ('${table.tableAlias}查看', '${id1}', 'sys_${classNameLowerCase}_show', '2', 'sys_${classNameLowerCase}_show', '1', '${table.tableAlias}查看');
INSERT INTO `resources` (`name`, `parentId`, `resKey`, `type`, `resUrl`, `level`, `description`) VALUES ('${table.tableAlias}修改', '${id1}', 'sys_${classNameLowerCase}_edit', '2', 'sys_${classNameLowerCase}_edit', '2', '${table.tableAlias}修改');
INSERT INTO `resources` (`name`, `parentId`, `resKey`, `type`, `resUrl`, `level`, `description`) VALUES ('${table.tableAlias}删除', '${id1}', 'sys_${classNameLowerCase}_delete', '2', 'sys_${classNameLowerCase}_delete', '3', '${table.tableAlias}删除');
INSERT INTO `resources` (`name`, `parentId`, `resKey`, `type`, `resUrl`, `level`, `description`) VALUES ('${table.tableAlias}增加', '${id1}', 'sys_${classNameLowerCase}_addUI', '2', 'sys_${classNameLowerCase}_addUI', '4', '${table.tableAlias}增加');
INSERT INTO `resources` (`name`, `parentId`, `resKey`, `type`, `resUrl`, `level`, `description`) VALUES ('${table.tableAlias}上传', '${id1}', 'sys_${classNameLowerCase}_upLoadFile', '2', 'sys_${classNameLowerCase}_upLoadFile', '5', '${table.tableAlias}上传');
INSERT INTO `resources` (`name`, `parentId`, `resKey`, `type`, `resUrl`, `level`, `description`) VALUES ('${table.tableAlias}导出', '${id1}', 'sys_${classNameLowerCase}_exportfiles', '2', 'sys_${classNameLowerCase}_exportfiles', '6', '${table.tableAlias}导出');
