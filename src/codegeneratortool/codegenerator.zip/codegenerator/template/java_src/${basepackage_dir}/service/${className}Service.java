<#include "/java_copyright.include">
<#assign className = table.className>   
<#assign classNameLower = className?uncap_first> 
package ${basepackage}.service;
import com.github.pagehelper.Page;
import java.util.List;
<#include "/java_imports.include">

<#include "/java_author.include">
public interface ${className}Service{

	List<${className}> query(Page<${className}> page, ${className} ${classNameLower});

	List<${className}> queryAll(${className} ${classNameLower});
	
	void add(${className} ${classNameLower});
	
	void addAll(${className} ${classNameLower});
	
	void delete(String id);
	
	void modify(${className} ${classNameLower});
	
	${className} getById(String id);
	
	List<${className}> findAll();
	
	<#list table.columns as column>
	<#if column.unique && !column.pk>
	@Transactional(readOnly=true)
	${className} getBy${column.columnName}(${column.javaType} v);
	</#if>
	</#list>
	
}
