<#include "/java_copyright.include">
<#assign className = table.className>   
<#assign classNameLower = className?uncap_first>   
package ${basepackage}.dao;

import com.ez.base.BaseDao;
import ${basepackage}.entity.${className};
import org.springframework.dao.DataAccessException;

import java.util.List;

<#include "/java_author.include">
public interface ${className}Dao extends BaseDao<${className}>{
	List<${className}> findAll() throws DataAccessException;

}
